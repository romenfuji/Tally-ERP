# Tally-ERP9-Cracked
All features of the paid version of Tally ERP9 are available here.

Steps to safely download and install cracked version of Tally ERP9 safely on your (Windows 7/8/10/11).
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

I WILL ADD IMAGES FOR BETTER UNDERSTANDING THE INSTALLATION .........................................

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Step 1 --> Click on Code and then click on Download ZIP. (as shown in the image below).

![image](https://user-images.githubusercontent.com/79533228/158681086-d9034b5a-11bd-4ff0-ac50-e2c32641a5c5.png)

Step 2 --> Goto Windows Settings > Virus and Threat Protection and click on Manage Settings under Virus and Threat Protection Settings.

![image](https://user-images.githubusercontent.com/79533228/158681643-99acb00d-bb57-47d8-b908-9830c14a15f6.png)

Step 3 --> Now Scroll down and click on add or remove exclusion.

![image](https://user-images.githubusercontent.com/79533228/158681833-45dc7972-8e95-4f0b-977d-89d2cfacfd1a.png)

Step 4 --> Click on "Add an exclusion" and then click on Folder.

![image](https://user-images.githubusercontent.com/79533228/158682360-15b96ddb-5f13-46b6-9942-0370a69b58da.png)

Step 5 --> Now Create a folder where you want to extract the downloaded file, we need to use this exclusion method because the Windows Defender will regard our crack as a virus and will not allow us to install it so we make an exclusion to the Defender.

Step 6 --> After Creating a folder, now select that folder in the exclusion list.

![image](https://user-images.githubusercontent.com/79533228/158683053-2efa37dd-54e6-48c7-b15f-f894782e06ba.png)

Step 7 --> Now extract the downloaded file to the exclusion folder.

![image](https://user-images.githubusercontent.com/79533228/158683349-f214c51c-e053-47b1-be98-54f0861ee848.png)

![image](https://user-images.githubusercontent.com/79533228/158683578-06ca9936-8839-4628-bdd7-719e72173535.png)

Step 8 --> Now open the extracted folder and click on Setup.exe

![image](https://user-images.githubusercontent.com/79533228/158683733-67084644-5bd8-472c-aec8-6dc1412fe079.png)

Step 9 --> Click Next

![image](https://user-images.githubusercontent.com/79533228/158683891-7a8d8cf3-ebf6-4137-97a2-325ff5b7e8e7.png)

Step 10 --> Choose where to install Tally ERP9 (I created a folder named Tally ERP9 and set the installation directory to that folder.) and then click on Next.

![image](https://user-images.githubusercontent.com/79533228/158684379-75838fd5-322e-4817-b77c-8588c8d936f5.png)

![image](https://user-images.githubusercontent.com/79533228/158684444-80ce83fd-a15b-4558-9de0-7ba6f381ab01.png)

Step 11 --> Click on Install

![image](https://user-images.githubusercontent.com/79533228/158684581-674e1d0a-6613-4a5a-9756-7ab41064c2e2.png)

Step 12 --> Once the Installation is complete click on Finish.

![image](https://user-images.githubusercontent.com/79533228/158684755-b5c8c2a5-58f5-4c80-88b3-0ccb1cde60db.png)

**Note : We have succesfully installed Tally ERP9 on your Windows. Now it's time to crack the installed software.

Step 13 --> Open the Exlusion Folder, then open the Cracked Folder and copy the tally.exe file

![image](https://user-images.githubusercontent.com/79533228/158685507-7376d4ca-f673-4fe6-8ef7-a6a5463efc36.png)

Step 14 --> Now go to the Tally ERP9 installation Directory (i.e. The place where you installed Tally ERP9)

![image](https://user-images.githubusercontent.com/79533228/158685710-f6db3cdd-349e-4bea-9e70-76a871b55e78.png)

** For those who don't know where is Tally ERP9 installed on their system can go to the installation directory by right clicking on the Tally ERP9 icon and clicking on open file location.

Step 15 --> Add the Tally ERP9 file to the Exclusion list in the Virus and Threat Protection.

![image](https://user-images.githubusercontent.com/79533228/158686116-1071e32c-2d62-4a92-988e-3274921771a0.png)

Step 16 --> Now paste the tally.exe file (that you copied from the exclusion folder) in the Tally ERP9 installation directory.

![image](https://user-images.githubusercontent.com/79533228/158686328-7d68c8de-ef37-454e-ba41-4e14486d5a3f.png)

![image](https://user-images.githubusercontent.com/79533228/158686571-30f0199e-467a-44bb-ac25-cb6f9f2e64a4.png)

Click on Replace the file in the destination folder.


Step 17 --> Now run the Tally ERP9 from the desktop or the application menu (Run as Administrator). Click on Allow Access

![image](https://user-images.githubusercontent.com/79533228/158686999-d5063ec7-e57a-42b2-994d-c82c8fc1e4ac.png)

Step 18 --> Let's proceed towards the Activation of Tally, press 'A' and hit enter.

![image](https://user-images.githubusercontent.com/79533228/158687305-ed65b8ea-a7c8-4eeb-b876-8fcc484e93c3.png)

Step 19 --> Hit enter again.

![image](https://user-images.githubusercontent.com/79533228/158687444-c3001234-9688-40cc-b796-e0ad96c3d57e.png)

Step 20 --> Now enter random data into the Serial Number, Activation Key and the Email id of the Administrator and hit enter.

![image](https://user-images.githubusercontent.com/79533228/158687872-8381b4ac-163f-4973-a32b-2a3b2c07ae3c.png)

You will see a message box like this.

![image](https://user-images.githubusercontent.com/79533228/158687951-998ceb09-69f9-4c58-8fd2-aad976b9b6a4.png)

Step 21 --> Exit Tally ERP9 by pressing Esc button on you keyboard and when prompted yes or no for quitting then press 'y' on your keyboard.

![image](https://user-images.githubusercontent.com/79533228/158688260-db4de632-e8ce-42e1-b50c-67c8eb7a0dcb.png)

Step 22 --> Now open the Tally ERP9 installation directory. You will see a file named "tally_req.lic".

![image](https://user-images.githubusercontent.com/79533228/158688512-d52fa23b-62c2-4da6-bed0-eb7e5c86f184.png)

Step 23 --> Rename "tally_req.lic" to "tally.lic"

![image](https://user-images.githubusercontent.com/79533228/158688751-6ef72410-9393-4420-87fc-b945db44bbf9.png)

Steo 24 --> Open your Tally ERP9 from Desktop or Applications Menu, you will be able to work on Tally now with all the paid features.

![image](https://user-images.githubusercontent.com/79533228/158689251-b774c193-f4b6-4d75-8c89-21c0937c9a66.png)

Hoorah!! Tally ERP9 is succesfully cracked and is ready to use.

